import pygame
pygame.init()

tela = pygame.display.set_mode((800, 600))
pygame.display.set_caption("Formas básicas")

rodando = True
while rodando:
    for evento in pygame.event.get():
        if evento.type == pygame.QUIT:
            rodando = False

    tela.fill((0, 0, 0))  # fundo preto

    pygame.draw.rect(tela, (255, 0, 0), (100, 100, 100, 50))
    pygame.draw.circle(tela, (0, 255, 0), (400, 300), 40)
    pygame.draw.polygon(tela, (0, 0, 255), [(600, 100), (700, 200), (500, 200)])
    pygame.draw.line(tela, (255, 255, 255), (0, 500), (800, 500), 2)

    pygame.display.update()

pygame.quit()
